#ifndef APP_TIM_H
#define APP_TIM_H

extern __IO uint8_t time_up;

#endif
